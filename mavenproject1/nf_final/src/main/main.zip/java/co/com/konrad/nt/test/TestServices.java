package co.com.konrad.nt.test;

import co.com.konrad.nt.logic.UsuarioLogic;
import com.google.gson.Gson;


public class TestServices {
	
    public static void main(String[] args) {
        //UsuarioLogic usuariologic = new UsuarioLogic();
        //usuariologic.iniciar_sesion("correo@correp.com", "123456");
    }

}
